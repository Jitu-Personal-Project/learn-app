import { ensureDirs, getDataFiles, importData } from "./util";
import { generateComponent } from "./componentGenerator";
// import { generateRoutes } from "./routesGenerator";

// Main generator function
const generate = async (): Promise<void> => {
  console.log("🚀 Starting component and routes generation...");

  // Ensure all necessary directories exist
  ensureDirs();

  // Get all data files
  const dataFilePaths: string[] = await getDataFiles();

  if (!dataFilePaths || dataFilePaths.length === 0) {
    console.error(
      "❌ No data files found. Please add data files in the src/data directory."
    );
    return;
  }

  console.log(`📁 Found ${dataFilePaths.length} data files`);

  // Import data from all files
  const dataFiles: any[] = [];
  for (const filePath of dataFilePaths) {
    console.log(`📄 Processing: ${filePath}`);
    const data = await importData(filePath);
    if (data) {
      dataFiles.push(data);
    }
  }

  // Generate components for each data file
  let componentsGenerated = 0;
  for (const data of dataFiles) {
    const success: boolean = await generateComponent(data);
    if (success) {
      componentsGenerated++;
    }
  }

  console.log(`✅ Generated ${componentsGenerated} components`);

  // Generate routes file
  //   const routesGenerated: boolean = await generateRoutes(dataFiles);
  //   if (routesGenerated) {
  //     console.log("✅ Generated routes configuration");
  //   } else {
  //     console.error("❌ Failed to generate routes configuration");
  //   }

  console.log("🎉 Generation completed!");
};

// Run the generator
generate().catch((error: unknown) => {
  console.error("❌ An error occurred during generation:", error);
});
