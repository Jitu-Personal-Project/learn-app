import Layout from "./Layout/Layout";
import { AppProvider } from "./contexts/context"; // Import the context, not the hook
import "./App.css";

function App() {
  return (
    <AppProvider>
      <Layout />
    </AppProvider>
  );
}

export default App;
