import React from "react";
import TopNav from "../Components/TopNav/TopNav";
import Sidebar from "../Components/Sidebar/Sidebar";
import "./HomeLayout.css";
import { useAppContext } from "../../contexts/context";

export default function HomeLayout() {
  const { appCurrentTheme } = useAppContext();
  return (
    <div
      className={`${appCurrentTheme.value}-theme theme-bg-secondary theme-bg-img home-layout-wrp full-screen overflow-hidden flex-start`}
    >
      <TopNav />
      <div className="home-layout-content-wrp full-width">
        <Sidebar />

        <div
          className={`${appCurrentTheme.value}-theme home-layout-content theme-bg `}
        >
          {/* Main content goes here */}
          <h1>Welcome to the Home Layout</h1>
          <p>This is where the main content will be displayed.</p>
        </div>
      </div>
    </div>
  );
}
