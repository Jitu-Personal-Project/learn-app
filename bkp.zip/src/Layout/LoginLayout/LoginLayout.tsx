import React from "react";

export default function LoginLayout() {
  return <div>LoginLayout</div>;
}
