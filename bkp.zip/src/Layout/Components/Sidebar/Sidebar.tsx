// crete reusable sidebar component
import React from "react";
import {
  Box,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import { useAppContext } from "../../../contexts/context";
import "./Sidebar.css";

export default function Sidebar() {
  const { isSidebar, closeSidebar, handelSidebar, appCurrentTheme } =
    useAppContext();

  const toggleDrawer =
    (open: boolean) => (event: React.KeyboardEvent | React.MouseEvent) => {
      if (
        (event.type === "keydown" &&
          (event as React.KeyboardEvent).key === "Tab") ||
        (event as React.KeyboardEvent).key === "Shift"
      ) {
        return;
      }
      handelSidebar(open);
    };

  const list = () => (
    <Box
      sx={{ width: 250 }}
      role="presentation"
      onClick={toggleDrawer(false)}
      onKeyDown={toggleDrawer(false)}
    >
      <List>
        {["Home", "Profile", "Settings"].map((text, index) => (
          <ListItem component="div" key={text}>
            <ListItemIcon>
              <MenuIcon />
            </ListItemIcon>
            <ListItemText primary={text} />
          </ListItem>
        ))}
      </List>
    </Box>
  );

  return (
    <div
      className={`${appCurrentTheme.value}-theme ${
        appCurrentTheme.value
      }-theme-sidebar theme-bg sidebar-wrp border-right full-height ${
        isSidebar ? "open" : "closed"
      }`}
    >
      {JSON.stringify(isSidebar)}
      ssssss <br />
      ssssss <br />
      ssssss <br />
      ssssss <br />
      ssssss <br />
      ssssss <br />
      ssssss <br />
      ssssss <br />
      ssssss <br />
      ssssss <br />
    </div>
  );
}
